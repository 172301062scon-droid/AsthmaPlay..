package com.example.ui.screens.games

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

data class TriggerItem(
    val id: Int,
    val name: String,
    val emoji: String,
    val isTrigger: Boolean,
    val explanation: String
)

@Composable
fun TriggerGameScreen(
    onBack: () -> Unit,
    onAwardPoints: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val itemsList = remember {
        listOf(
            TriggerItem(1, "Flower Pollen", "🌼", true, "Pollen floats in spring air and can tickle sensitive airways!"),
            TriggerItem(2, "Fresh Apple", "🍎", false, "Healthy fruit gives your body vitamins and is super safe!"),
            TriggerItem(3, "Cold Winter Air", "❄️", true, "Cold air can make breathing tubes twitch and narrow!"),
            TriggerItem(4, "Campfire Smoke", "🔥", true, "Smoke contains tiny irritating particles that irritate lungs!"),
            TriggerItem(5, "Clean Water", "💧", false, "Drinking fresh water keeps your body hydrated and healthy!"),
            TriggerItem(6, "Dust Mites", "🕷️", true, "Microscopic dust bugs love old pillows and can cause coughing!"),
            TriggerItem(7, "Reading a Book", "📚", false, "Quiet relaxing activities are wonderful for your body and mind!"),
            TriggerItem(8, "Pet Dander", "🐱", true, "Furry animals shed tiny flakes of skin that can trigger sneezing and wheezing!")
        )
    }

    val guessedItems = remember { mutableStateMapOf<Int, Boolean>() } // itemId to userGuess (true = trigger, false = safe)
    var score by remember { mutableIntStateOf(0) }
    var pointsClaimed by remember { mutableStateOf(false) }

    val allGuessed = guessedItems.size == itemsList.size

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Trigger Detective",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = WarmOrange
                    )
                    Text(
                        text = "Tap each card to classify: Trigger or Safe?",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = WarmOrangeLight
                ) {
                    Text(
                        text = "Score: $score / ${itemsList.size}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = WarmOrange,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFFF8FBFE))
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (allGuessed) {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = SoftGreenLight),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "🎉 Detective Mission Complete! 🎉", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = SoftGreenDark)
                        Text(text = "You correctly spotted $score out of ${itemsList.size} items!", fontSize = 13.sp, color = SoftGreenDark)
                        if (!pointsClaimed) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    pointsClaimed = true
                                    onAwardPoints(25)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SoftGreen),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Claim +25 Hero XP!", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Text(text = "⭐ Points Added to Your Profile! ⭐", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SoftGreenDark, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(itemsList) { item ->
                    val userGuess = guessedItems[item.id]
                    val isRevealed = userGuess != null
                    val isCorrect = userGuess == item.isTrigger

                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = when {
                                !isRevealed -> Color.White
                                isCorrect -> SoftGreenLight
                                else -> WarmOrangeLight
                            }
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.5.dp,
                                when {
                                    !isRevealed -> Color(0xFFE2E8F0)
                                    isCorrect -> SoftGreen
                                    else -> WarmOrange
                                },
                                RoundedCornerShape(18.dp)
                            )
                            .testTag("trigger_item_${item.id}")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = item.emoji, fontSize = 42.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = item.name,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B),
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            if (!isRevealed) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            guessedItems[item.id] = true
                                            if (item.isTrigger) score++
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = WarmOrange),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Trigger", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = {
                                            guessedItems[item.id] = false
                                            if (!item.isTrigger) score++
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = SoftGreen),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Safe", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (isCorrect) Icons.Default.Check else Icons.Default.Close,
                                        contentDescription = null,
                                        tint = if (isCorrect) SoftGreen else WarmOrange,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (item.isTrigger) "Asthma Trigger" else "Safe & Healthy",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isCorrect) SoftGreenDark else Color(0xFF9A3412)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = item.explanation,
                                    fontSize = 10.sp,
                                    color = Color.DarkGray,
                                    lineHeight = 13.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
