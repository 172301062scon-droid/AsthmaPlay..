package com.example.ui.screens.learn

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.models.Lesson
import com.example.ui.theme.*

@Composable
fun LessonDetailScreen(
    lesson: Lesson,
    totalLessons: Int,
    onBack: () -> Unit,
    onCompleteLesson: (Int) -> Unit,
    onNextLesson: ((Int) -> Unit)?,
    modifier: Modifier = Modifier
) {
    // Map of question id to selected option index
    val selectedAnswers = remember { mutableStateMapOf<Int, Int>() }
    val isSubmitted = remember { mutableStateOf(false) }

    val imageRes = when (lesson.imageResName) {
        "img_inhaler_spacer" -> R.drawable.img_inhaler_spacer
        "img_hero_mascot" -> R.drawable.img_hero_mascot
        else -> R.drawable.img_lungs_comparison
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Lesson ${lesson.number} of $totalLessons",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Text(
                        text = lesson.title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = SkyBlueDark,
                        maxLines = 1
                    )
                }
                if (lesson.isCompleted) {
                    AssistChip(
                        onClick = {},
                        label = { Text("Done", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) },
                        colors = AssistChipDefaults.assistChipColors(containerColor = SoftGreenLight, labelColor = SoftGreenDark)
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFFF8FBFE))
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 48.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Illustrated Banner
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                ) {
                    Image(
                        painter = painterResource(id = imageRes),
                        contentDescription = lesson.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // 2. Title & Subtitle
            item {
                Column {
                    Text(
                        text = lesson.title,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = lesson.subtitle,
                        fontSize = 14.sp,
                        color = SkyBlueDark,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // 3. Narrative Text Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = lesson.fullText,
                            fontSize = 14.sp,
                            color = Color(0xFF334155),
                            lineHeight = 22.sp
                        )
                    }
                }
            }

            // 4. Quick Fact Box
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = GoldenYellowLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(GoldenYellow),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lightbulb,
                                contentDescription = "Fact",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Quick Fact!",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFB45309)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = lesson.quickFact,
                                fontSize = 13.sp,
                                color = Color(0xFF78350F),
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }

            // 5. Superhero Practical Tip
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = TealLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(TealDark),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Tip",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Superhero Practice Tip",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TealDark
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = lesson.practicalTip,
                                fontSize = 13.sp,
                                color = Color(0xFF0F4C5C),
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }

            // 6. Review Questions Header
            item {
                Text(
                    text = "Review Challenge: Test Your Knowledge",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )
            }

            // Questions items
            items(lesson.questions.size) { index ->
                val q = lesson.questions[index]
                val selected = selectedAnswers[q.id]

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Question ${index + 1}: ${q.question}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        q.options.forEachIndexed { optIdx, optText ->
                            val isChoice = selected == optIdx
                            val isCorrect = optIdx == q.correctIndex

                            val borderCol = when {
                                isSubmitted.value && isChoice && isCorrect -> SoftGreen
                                isSubmitted.value && isChoice && !isCorrect -> EmergencyRed
                                isChoice -> SkyBlueDark
                                else -> Color(0xFFE2E8F0)
                            }

                            val bgCol = when {
                                isSubmitted.value && isChoice && isCorrect -> SoftGreenLight
                                isSubmitted.value && isChoice && !isCorrect -> EmergencyRedLight
                                isChoice -> SkyBlueLight
                                else -> Color.White
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(1.5.dp, borderCol, RoundedCornerShape(12.dp))
                                    .background(bgCol)
                                    .clickable {
                                        selectedAnswers[q.id] = optIdx
                                    }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isChoice,
                                    onClick = { selectedAnswers[q.id] = optIdx },
                                    colors = RadioButtonDefaults.colors(selectedColor = SkyBlueDark)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = optText,
                                    fontSize = 13.sp,
                                    color = Color(0xFF1E293B)
                                )
                            }
                        }

                        // Explanation after selection/submit
                        if (isSubmitted.value && selected != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            val correct = selected == q.correctIndex
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (correct) SoftGreenLight else WarmOrangeLight
                                )
                            ) {
                                Text(
                                    text = if (correct) "🌟 ${q.explanation}" else "💡 Nice try! Correct answer: ${q.options[q.correctIndex]}. ${q.explanation}",
                                    fontSize = 12.sp,
                                    color = if (correct) SoftGreenDark else Color(0xFFC05621),
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 7. Complete & Navigation Buttons
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            isSubmitted.value = true
                            onCompleteLesson(lesson.id)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (lesson.isCompleted) SoftGreen else SkyBlueDark
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("complete_lesson_button")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (lesson.isCompleted) "Lesson Completed! (+15 XP)" else "Complete Lesson & Check Answers",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    if (onNextLesson != null) {
                        OutlinedButton(
                            onClick = { onNextLesson(lesson.id + 1) },
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Text("Next Lesson →", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
