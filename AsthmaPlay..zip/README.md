# AsthmaPlay — Android Application

AsthmaPlay is an AI-powered pediatric asthma education and self-management application designed for school-age children (aged 6–12), parents/caregivers, and healthcare researchers.

## Prerequisites

- **JDK**: Java 17 or Java 21
- **Android SDK**: API Level 34–36 (Build Tools 36.0.0+)

## Quick Build Command

To assemble the debug APK on any clean machine or in GitHub Actions CI:

```bash
chmod +x gradlew
./gradlew assembleDebug
```

### Output APK Path

Once the build completes successfully, the signed debug APK is located at:
```
app/build/outputs/apk/debug/app-debug.apk
```

## Running Unit Tests

```bash
./gradlew testDebugUnitTest
```

## Configuration & Environment Variables (Optional)

The project builds out-of-the-box with **no secrets, API keys, or manual setup required**:
- A pre-configured `debug.keystore` (password: `android`, alias: `androiddebugkey`) is included in the project root.
- A standalone `app/google-services.json` is included to satisfy Google Services tooling without requiring external Firebase provisioning.
- If you wish to enable online Gemini AI streaming responses, create an optional `.env` file in the project root:
  ```env
  GEMINI_API_KEY=your_gemini_api_key_here
  ```
  If `.env` is omitted or empty, the app automatically falls back to its built-in pediatric clinical knowledge base.

## GitHub Actions CI Workflow Example

```yaml
name: Build AsthmaPlay APK

on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v4

      - name: Set up Java 21
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '21'
          cache: 'gradle'

      - name: Make Gradle executable
        run: chmod +x gradlew

      - name: Build Debug APK
        run: ./gradlew assembleDebug --stacktrace

      - name: Upload Debug APK
        uses: actions/upload-artifact@v4
        with:
          name: app-debug
          path: app/build/outputs/apk/debug/app-debug.apk
```
