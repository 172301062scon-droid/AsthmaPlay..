pluginManagement {
  repositories {
    google {
      content {
        includeGroupByRegex("com\\.android.*")
        includeGroupByRegex("com\\.google.*")
        includeGroupByRegex("androidx.*")
      }
    }
    mavenCentral()
    gradlePluginPortal()
  }
}

plugins { id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0" }

dependencyResolutionManagement {
  repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
  repositories {
    google()
    mavenCentral()
  }
}

rootProject.name = "AsthmaPlay"

include(":app")

// Ensure debug.keystore is available in both root and app/ for CI / GitHub Actions
val base64Keystore = file("debug.keystore.base64")
listOf(file("debug.keystore"), file("app/debug.keystore")).forEach { targetFile ->
  if (!targetFile.exists() && base64Keystore.exists()) {
    try {
      val decoded = java.util.Base64.getDecoder().decode(base64Keystore.readText().trim())
      targetFile.writeBytes(decoded)
    } catch (_: Exception) {}
  }
}

val rootKeystore = file("debug.keystore")
val appKeystore = file("app/debug.keystore")
if (rootKeystore.exists() && !appKeystore.exists()) {
  try {
    appKeystore.writeBytes(rootKeystore.readBytes())
  } catch (_: Exception) {}
}

