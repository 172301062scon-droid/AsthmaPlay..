package com.example.ui.screens.parent

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ChildProfile
import com.example.data.models.Lesson
import com.example.data.models.MedicationReminder
import com.example.data.models.SymptomLog
import com.example.ui.theme.*

@Composable
fun ParentDashboardScreen(
    childProfile: ChildProfile,
    lessons: List<Lesson>,
    reminders: List<MedicationReminder>,
    symptomLogs: List<SymptomLog>,
    onVerifyPin: (String) -> Boolean,
    onUpdatePin: (String) -> Boolean,
    onUpdateProfile: (String, Int, String, String, String) -> Unit,
    onBackToChildMode: () -> Unit,
    onNavigateToResearch: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isPinUnlocked by remember { mutableStateOf(false) }
    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showEditPinDialog by remember { mutableStateOf(false) }
    var pinChangeSuccessNotice by remember { mutableStateOf<String?>(null) }

    val avatarEmoji = when (childProfile.sex.lowercase()) {
        "girl" -> "👧"
        "boy" -> "👦"
        else -> "🧒"
    }

    if (!isPinUnlocked) {
        // Parent PIN Lock Screen
        Scaffold(
            topBar = {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackToChildMode) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Text(
                        text = "Parental Gate",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = SkyBlueDark
                    )
                }
            }
        ) { innerPadding ->
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .background(Color(0xFFF8FBFE))
                    .padding(innerPadding)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(70.dp)
                        .clip(CircleShape)
                        .background(SkyBlueLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Lock",
                        tint = SkyBlueDark,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Parent Access Lock",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )

                Text(
                    text = "Please enter your 4-digit Parent PIN (Default is 1234)",
                    fontSize = 13.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                OutlinedTextField(
                    value = enteredPin,
                    onValueChange = {
                        if (it.length <= 4) {
                            enteredPin = it
                            pinError = false
                        }
                    },
                    label = { Text("Parent PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    isError = pinError,
                    modifier = Modifier
                        .width(220.dp)
                        .testTag("parent_pin_input")
                )

                if (pinError) {
                    Text(
                        text = "Incorrect PIN. Please try again.",
                        color = EmergencyRed,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        if (onVerifyPin(enteredPin)) {
                            isPinUnlocked = true
                            pinError = false
                        } else {
                            pinError = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SkyBlueDark),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.width(220.dp)
                ) {
                    Text("Unlock Dashboard", fontWeight = FontWeight.Bold)
                }
            }
        }
        return
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackToChildMode) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Parent / Caregiver Dashboard",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = SkyBlueDark
                    )
                    Text(
                        text = "Manage ${childProfile.nickname}'s care and asthma action plan",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
                IconButton(onClick = onNavigateToResearch) {
                    Icon(Icons.Default.Science, contentDescription = "Research Assessment", tint = RoyalPurple)
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFFF8FBFE))
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 48.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Success notice if PIN was changed
            if (pinChangeSuccessNotice != null) {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = SoftGreenLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = SoftGreenDark)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = pinChangeSuccessNotice ?: "",
                                color = SoftGreenDark,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // Child profile card (with Nickname, Age, Sex, Doctor, and Edit button)
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(SkyBlueLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = avatarEmoji, fontSize = 30.sp)
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${childProfile.nickname}'s Profile",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B)
                            )
                            Text(
                                text = "Age: ${childProfile.age} years  •  Sex: ${childProfile.sex}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = SkyBlueDark
                            )
                            Text(
                                text = childProfile.levelName,
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Doctor: ${childProfile.emergencyDoctorName} (${childProfile.emergencyDoctorPhone})",
                                fontSize = 11.sp,
                                color = Color(0xFF475569)
                            )
                        }

                        IconButton(
                            onClick = { showEditProfileDialog = true },
                            modifier = Modifier.testTag("edit_child_profile_button")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = SkyBlueDark)
                        }
                    }
                }
            }

            // Parent PIN Settings & Security Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFF1F5F9)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = "Security PIN",
                                tint = SkyBlueDark,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Parent Access PIN",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B)
                            )
                            Text(
                                text = "Protects parent controls, reports, and settings",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }

                        OutlinedButton(
                            onClick = { showEditPinDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("edit_parent_pin_button")
                        ) {
                            Icon(Icons.Default.Password, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Edit PIN", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Quick Stats Row
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "${lessons.count { it.isCompleted }}/${lessons.size}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = SkyBlueDark)
                            Text(text = "Lessons Done", fontSize = 11.sp, color = Color.Gray)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "${reminders.count { it.isEnabled }} Active", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = WarmOrange)
                            Text(text = "Reminders", fontSize = 11.sp, color = Color.Gray)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "${symptomLogs.size} Logs", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = SoftGreenDark)
                            Text(text = "Symptom Entries", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
            }

            // Asthma Action Plan Zones
            item {
                Column {
                    Text(
                        text = "Individualized Asthma Action Plan",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B)
                    )
                    Text(
                        text = "Clinician-provided zone instructions",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Green Zone
                    ZoneCard(
                        title = "🟢 GREEN ZONE (Doing Well)",
                        description = childProfile.greenZoneAction,
                        color = SoftGreen,
                        bg = SoftGreenLight
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Yellow Zone
                    ZoneCard(
                        title = "🟡 YELLOW ZONE (Caution / Flare-Up)",
                        description = childProfile.yellowZoneAction,
                        color = WarmOrange,
                        bg = WarmOrangeLight
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Red Zone
                    ZoneCard(
                        title = "🔴 RED ZONE (Emergency Alert)",
                        description = childProfile.redZoneAction,
                        color = EmergencyRed,
                        bg = EmergencyRedLight
                    )
                }
            }

            // Export Doctor Summary
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = SkyBlueLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "📋", fontSize = 24.sp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Export Report for Doctor Visit",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = SkyBlueDark
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Generate a comprehensive clinical summary of ${childProfile.nickname}'s symptom logs, medication habits, and learning progress to share with your pediatrician.",
                            fontSize = 12.sp,
                            color = Color(0xFF0369A1),
                            lineHeight = 16.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                val reportText = buildString {
                                    appendLine("=== ASTHMAPLAY CLINICAL PROGRESS REPORT ===")
                                    appendLine("Patient Nickname: ${childProfile.nickname}")
                                    appendLine("Age: ${childProfile.age} years")
                                    appendLine("Sex: ${childProfile.sex}")
                                    appendLine("Clinician: ${childProfile.emergencyDoctorName}")
                                    appendLine("Completed Education Lessons: ${lessons.count { it.isCompleted }} of ${lessons.size}")
                                    appendLine("Learning Points: ${childProfile.points} (${childProfile.levelName})")
                                    appendLine("Active Reminders: ${reminders.joinToString { "${it.title} at ${it.timeString}" }}")
                                    appendLine("\nRecent Symptom Logs:")
                                    symptomLogs.take(5).forEach { log ->
                                        appendLine("- [${log.dateString}] Severity: ${log.severity.label}. Symptoms: ${log.symptoms.joinToString()}. Triggers: ${log.triggers.joinToString()}. Notes: ${log.notes}")
                                    }
                                }

                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, "AsthmaPlay Progress Report - ${childProfile.nickname}")
                                    putExtra(Intent.EXTRA_TEXT, reportText)
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Report via"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SkyBlueDark),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share / Export Doctor Report", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }

            // Research Module shortcut
            item {
                OutlinedButton(
                    onClick = onNavigateToResearch,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Science, contentDescription = null, tint = RoyalPurple)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Open Nursing Research Assessment Module", color = RoyalPurple, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // Edit Child Profile Dialog (Nickname, Age, Sex, Doctor, Phone)
    if (showEditProfileDialog) {
        var editName by remember { mutableStateOf(childProfile.nickname) }
        var editAge by remember { mutableIntStateOf(childProfile.age) }
        var editSex by remember { mutableStateOf(childProfile.sex) }
        var editDoctor by remember { mutableStateOf(childProfile.emergencyDoctorName) }
        var editPhone by remember { mutableStateOf(childProfile.emergencyDoctorPhone) }

        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            title = { Text("Edit Child Profile", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Child Nickname") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_nickname_input")
                    )

                    // Age Stepper
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFF8FAFC))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Child's Age: $editAge years",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1E293B)
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { if (editAge > 6) editAge-- },
                                enabled = editAge > 6,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.RemoveCircle, contentDescription = "Decrease Age", tint = SkyBlueDark)
                            }
                            Text(
                                text = "$editAge",
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp)
                            )
                            IconButton(
                                onClick = { if (editAge < 12) editAge++ },
                                enabled = editAge < 12,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.AddCircle, contentDescription = "Increase Age", tint = SkyBlueDark)
                            }
                        }
                    }

                    // Sex Selection
                    Column {
                        Text(
                            text = "Child's Sex:",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF334155)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("Boy", "Girl", "Other").forEach { sexOption ->
                                FilterChip(
                                    selected = editSex == sexOption,
                                    onClick = { editSex = sexOption },
                                    label = { Text(sexOption, fontSize = 12.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = editDoctor,
                        onValueChange = { editDoctor = it },
                        label = { Text("Pediatrician / Clinic") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = editPhone,
                        onValueChange = { editPhone = it },
                        label = { Text("Emergency Phone Number") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editName.isNotBlank()) {
                            onUpdateProfile(editName, editAge, editSex, editDoctor, editPhone)
                            showEditProfileDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SkyBlueDark),
                    modifier = Modifier.testTag("save_child_profile_button")
                ) {
                    Text("Save Changes", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Edit Parent PIN Dialog
    if (showEditPinDialog) {
        var currentPinInput by remember { mutableStateOf("") }
        var newPinInput by remember { mutableStateOf("") }
        var confirmPinInput by remember { mutableStateOf("") }
        var pinErrorMessage by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showEditPinDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Password, contentDescription = null, tint = SkyBlueDark)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Change Parent PIN", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Enter your current 4-digit PIN and set a new one.",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )

                    OutlinedTextField(
                        value = currentPinInput,
                        onValueChange = { if (it.length <= 4) currentPinInput = it },
                        label = { Text("Current PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("current_pin_input")
                    )

                    OutlinedTextField(
                        value = newPinInput,
                        onValueChange = { if (it.length <= 4) newPinInput = it },
                        label = { Text("New 4-Digit PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_pin_input")
                    )

                    OutlinedTextField(
                        value = confirmPinInput,
                        onValueChange = { if (it.length <= 4) confirmPinInput = it },
                        label = { Text("Confirm New PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("confirm_pin_input")
                    )

                    if (pinErrorMessage != null) {
                        Text(
                            text = pinErrorMessage ?: "",
                            color = EmergencyRed,
                            fontSize = 12.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (!onVerifyPin(currentPinInput)) {
                            pinErrorMessage = "Current PIN is incorrect."
                            return@Button
                        }
                        if (newPinInput.length != 4 || !newPinInput.all { it.isDigit() }) {
                            pinErrorMessage = "New PIN must be exactly 4 digits."
                            return@Button
                        }
                        if (newPinInput != confirmPinInput) {
                            pinErrorMessage = "New PIN and confirmation do not match."
                            return@Button
                        }

                        if (onUpdatePin(newPinInput)) {
                            showEditPinDialog = false
                            pinChangeSuccessNotice = "Parent PIN updated successfully!"
                        } else {
                            pinErrorMessage = "Failed to update PIN."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SkyBlueDark),
                    modifier = Modifier.testTag("save_pin_button")
                ) {
                    Text("Save New PIN", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditPinDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ZoneCard(
    title: String,
    description: String,
    color: Color,
    bg: Color
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(color.copy(alpha = 0.5f))),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                fontSize = 12.sp,
                color = Color(0xFF1E293B),
                lineHeight = 17.sp
            )
        }
    }
}
