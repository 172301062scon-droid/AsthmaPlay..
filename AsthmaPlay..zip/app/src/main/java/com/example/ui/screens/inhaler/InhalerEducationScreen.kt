package com.example.ui.screens.inhaler

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import kotlinx.coroutines.delay

data class InhalerStep(
    val stepNumber: Int,
    val title: String,
    val description: String,
    val tip: String
)

@Composable
fun InhalerEducationScreen(
    onBack: () -> Unit,
    onMastered: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedDeviceTab by remember { mutableIntStateOf(0) } // 0 = MDI + Spacer, 1 = MDI Mouthpiece, 2 = Dry Powder

    val mdiSpacerSteps = remember {
        listOf(
            InhalerStep(1, "Prepare & Shake!", "Take the cap off the inhaler and check the inside is clean. Shake the inhaler well up and down for 5 seconds.", "Shaking mixes the medicine and the propellant evenly!"),
            InhalerStep(2, "Assemble the Spacer!", "Insert the inhaler firmly into the back rubber opening of the spacer chamber.", "Keep the inhaler standing upright."),
            InhalerStep(3, "Fit the Mask or Mouthpiece!", "Breathe out gently all the way into the air. Place the mask over your child's nose and mouth, ensuring a snug, comfortable seal with no gaps.", "A good seal ensures no medicine leaks out around the cheeks."),
            InhalerStep(4, "Press Down ONCE!", "Press down on the canister ONCE to release a single puff of medicine into the spacer chamber.", "Always spray only ONE puff at a time into the chamber."),
            InhalerStep(5, "Breathe 5 Slow, Deep Breaths!", "Keep the mask in place. Breathe slowly and steadily IN and OUT through the spacer chamber 5 times.", "Count to 5 on your fingers slowly: 1... 2... 3... 4... 5!"),
            InhalerStep(6, "Rinse Your Mouth!", "If taking a daily steroid controller medicine, rinse your mouth with water and spit it out.", "This keeps your voice crystal clear and your throat healthy!")
        )
    }

    // Interactive 5-second breath counter
    var isTimerRunning by remember { mutableStateOf(false) }
    var timerCount by remember { mutableIntStateOf(5) }

    LaunchedEffect(isTimerRunning) {
        if (isTimerRunning) {
            timerCount = 5
            while (timerCount > 0) {
                delay(1000)
                timerCount--
            }
            isTimerRunning = false
        }
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Using Your Inhaler",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TealDark
                    )
                    Text(
                        text = "Clinician-reviewed step-by-step guide",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFFF8FBFE))
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 48.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Illustrated educational poster
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_inhaler_spacer),
                        contentDescription = "Inhaler and Spacer Guide",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // Device Tabs
            item {
                TabRow(
                    selectedTabIndex = selectedDeviceTab,
                    containerColor = Color.White,
                    contentColor = TealDark,
                    modifier = Modifier.clip(RoundedCornerShape(14.dp))
                ) {
                    Tab(
                        selected = selectedDeviceTab == 0,
                        onClick = { selectedDeviceTab = 0 },
                        text = { Text("MDI + Spacer", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedDeviceTab == 1,
                        onClick = { selectedDeviceTab = 1 },
                        text = { Text("Mouthpiece", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedDeviceTab == 2,
                        onClick = { selectedDeviceTab = 2 },
                        text = { Text("Dry Powder", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                }
            }

            // Interactive 5-Breath Timer Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = TealLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(TealDark),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isTimerRunning) "$timerCount" else "⏱️",
                                fontSize = if (isTimerRunning) 22.sp else 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isTimerRunning) "Breathe in & out slowly..." else "5-Breath Practice Timer",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TealDark
                            )
                            Text(
                                text = if (isTimerRunning) "Count with your buddy: $timerCount seconds remaining" else "Practice taking 5 calm breaths through the spacer",
                                fontSize = 11.sp,
                                color = Color(0xFF005662)
                            )
                        }

                        FilledTonalButton(
                            onClick = { isTimerRunning = true },
                            colors = ButtonDefaults.filledTonalButtonColors(containerColor = TealDark, contentColor = Color.White),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            enabled = !isTimerRunning
                        ) {
                            Text(if (isTimerRunning) "Running" else "Start")
                        }
                    }
                }
            }

            // Steps List
            itemsIndexed(mdiSpacerSteps) { index, step ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(SkyBlueLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${step.stepNumber}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = SkyBlueDark
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = step.title,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = step.description,
                                fontSize = 13.sp,
                                color = Color(0xFF475569),
                                lineHeight = 18.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFF1F5F9)
                            ) {
                                Text(
                                    text = "💡 ${step.tip}",
                                    fontSize = 11.sp,
                                    color = Color(0xFF0369A1),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Important Clinical Disclaimer Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = GoldenYellowLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "👩‍⚕️ Clinical Reminder: Your doctor, asthma educator, or nurse should demonstrate the exact technique for your specific inhaler model. Always follow clinician guidance.",
                        fontSize = 12.sp,
                        color = Color(0xFF854D0E),
                        modifier = Modifier.padding(14.dp),
                        lineHeight = 16.sp
                    )
                }
            }

            // Mark Mastered Button
            item {
                Button(
                    onClick = onMastered,
                    colors = ButtonDefaults.buttonColors(containerColor = TealDark),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("inhaler_mastered_button")
                ) {
                    Icon(Icons.Default.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("I Practiced & Understand (+20 XP)", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
