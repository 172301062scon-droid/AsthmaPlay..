package com.example.ui.screens.research

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Lesson
import com.example.data.models.ResearchAssessment
import com.example.data.models.ResearchQuestion
import com.example.ui.theme.*

@Composable
fun ResearchAssessmentScreen(
    assessment: ResearchAssessment,
    questions: List<ResearchQuestion>,
    lessons: List<Lesson>,
    onSubmitPreTest: (Int, Int) -> Unit,
    onSubmitPostTest: (Int, Int) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var activeTestMode by remember { mutableStateOf<String?>(null) } // null, "PRE", "POST"

    // If taking a test:
    if (activeTestMode != null) {
        val isPre = activeTestMode == "PRE"
        val userAnswers = remember { mutableStateMapOf<Int, Int>() }
        var isTestSubmitted by remember { mutableStateOf(false) }

        Scaffold(
            topBar = {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { activeTestMode = null }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Text(
                        text = if (isPre) "Baseline Pre-Test Questionnaire" else "Post-Intervention Knowledge Test",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = RoyalPurple
                    )
                }
            }
        ) { innerPadding ->
            LazyColumn(
                modifier = modifier
                    .fillMaxSize()
                    .background(Color(0xFFF8FBFE))
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 48.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = RoyalPurpleLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Participant Code: ${assessment.participantCode}",
                                fontWeight = FontWeight.Bold,
                                color = RoyalPurple,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "Please answer all 10 questions to the best of your ability. Answers are confidential and used to evaluate app effectiveness.",
                                fontSize = 11.sp,
                                color = Color(0xFF4A148C),
                                lineHeight = 15.sp
                            )
                        }
                    }
                }

                items(questions) { q ->
                    val selected = userAnswers[q.id]
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Q${q.id}. [${q.domain}]",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = RoyalPurple
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = q.questionText,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF1E293B)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            q.options.forEachIndexed { optIndex, optText ->
                                val isChoice = selected == optIndex
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isChoice) RoyalPurpleLight else Color(0xFFF8FAFC))
                                        .border(
                                            1.dp,
                                            if (isChoice) RoyalPurple else Color(0xFFE2E8F0),
                                            RoundedCornerShape(10.dp)
                                        )
                                        .clickable { userAnswers[q.id] = optIndex }
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = isChoice,
                                        onClick = { userAnswers[q.id] = optIndex },
                                        colors = RadioButtonDefaults.colors(selectedColor = RoyalPurple)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = optText, fontSize = 13.sp, color = Color(0xFF1E293B))
                                }
                            }
                        }
                    }
                }

                item {
                    val allAnswered = userAnswers.size == questions.size
                    Button(
                        onClick = {
                            val score = questions.count { userAnswers[it.id] == it.correctIndex }
                            if (isPre) {
                                onSubmitPreTest(score, questions.size)
                            } else {
                                onSubmitPostTest(score, questions.size)
                            }
                            activeTestMode = null
                        },
                        enabled = allAnswered,
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalPurple),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("submit_research_test_button")
                    ) {
                        Text(
                            text = if (allAnswered) "Submit Test Assessment" else "Please answer all questions (${userAnswers.size}/${questions.size})",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
        return
    }

    // Main Research Dashboard
    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Nursing Research Assessment",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = RoyalPurple
                    )
                    Text(
                        text = "Participant Code: ${assessment.participantCode}",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFFF8FBFE))
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 48.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Study Header Card
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(RoyalPurpleLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Science, contentDescription = null, tint = RoyalPurple)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Clinical Nursing Study",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = RoyalPurple
                                )
                                Text(
                                    text = "Effectiveness of an AI-Based Asthma Education App on Asthma Self-Management Knowledge",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1E293B),
                                    lineHeight = 17.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Institutional Ethics Protocol: Approved • Parental Consent & Child Assent: Verified • De-identified records only.",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }

            // Pre-Test & Post-Test Comparative Results Card
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Standardized Knowledge Evaluation",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Pre-test card
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = SkyBlueLight),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Baseline Pre-Test", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SkyBlueDark)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    if (assessment.isPreTestCompleted) {
                                        Text("${assessment.preTestScore}/${assessment.preTestTotal}", fontSize = 22.sp, fontWeight = FontWeight.Black, color = SkyBlueDark)
                                        Text("${(assessment.preTestScore.toFloat() / assessment.preTestTotal * 100).toInt()}% • ${assessment.preTestDate}", fontSize = 10.sp, color = Color.Gray)
                                    } else {
                                        Text("Pending", fontSize = 14.sp, color = Color.Gray)
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Button(
                                            onClick = { activeTestMode = "PRE" },
                                            colors = ButtonDefaults.buttonColors(containerColor = SkyBlueDark),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text("Start Pre-Test", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }

                            // Post-test card
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = if (assessment.isPostTestCompleted) SoftGreenLight else Color(0xFFF1F5F9)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Post-Intervention Test", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (assessment.isPostTestCompleted) SoftGreenDark else Color.Gray)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    if (assessment.isPostTestCompleted) {
                                        Text("${assessment.postTestScore}/${assessment.postTestTotal}", fontSize = 22.sp, fontWeight = FontWeight.Black, color = SoftGreenDark)
                                        val prePct = (assessment.preTestScore.toFloat() / assessment.preTestTotal * 100).toInt()
                                        val postPct = (assessment.postTestScore.toFloat() / assessment.postTestTotal * 100).toInt()
                                        val gain = postPct - prePct
                                        Text("$postPct% (+${gain}% gain)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SoftGreenDark)
                                    } else {
                                        Text("Not Taken Yet", fontSize = 12.sp, color = Color.Gray)
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Button(
                                            onClick = { activeTestMode = "POST" },
                                            colors = ButtonDefaults.buttonColors(containerColor = RoyalPurple),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text("Start Post-Test", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Educational Intervention Completion Record
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Intervention Adherence & Learning Dosage",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        val completedCount = lessons.count { it.isCompleted }
                        Text(
                            text = "Curriculum Modules Completed: $completedCount of ${lessons.size} (${(completedCount.toFloat() / lessons.size * 100).toInt()}%)",
                            fontSize = 13.sp,
                            color = Color(0xFF334155)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { completedCount.toFloat() / lessons.size },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(CircleShape),
                            color = SoftGreen,
                            trackColor = Color(0xFFE2E8F0)
                        )
                    }
                }
            }

            // Export De-identified Data for Statistical Analysis (SPSS / R / CSV)
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = RoyalPurpleLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "📊", fontSize = 24.sp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Export De-identified Research Dataset",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = RoyalPurple
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Export participant CSV/JSON record containing baseline score, post-test score, knowledge gain percentage, and completed educational modules.",
                            fontSize = 12.sp,
                            color = Color(0xFF4A148C),
                            lineHeight = 16.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                val preScore = if (assessment.isPreTestCompleted) assessment.preTestScore else 0
                                val postScore = if (assessment.isPostTestCompleted) assessment.postTestScore else 0
                                val csv = """
                                    participant_id,pre_test_score,pre_test_total,post_test_score,post_test_total,modules_completed,total_modules,knowledge_gain_percent
                                    ${assessment.participantCode},$preScore,10,$postScore,10,${lessons.count { it.isCompleted }},${lessons.size},${((postScore - preScore) * 10)}%
                                """.trimIndent()

                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/csv"
                                    putExtra(Intent.EXTRA_SUBJECT, "Research Assessment Data - ${assessment.participantCode}")
                                    putExtra(Intent.EXTRA_TEXT, csv)
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Export Dataset via"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalPurple),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export Research CSV Data", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
