package com.example.data.models

enum class UserRole {
    CHILD,
    PARENT,
    RESEARCHER
}

enum class SymptomSeverity(val label: String, val emoji: String, val colorHex: Long) {
    GOOD("Feeling Great", "😄", 0xFF4CAF50),
    MILD("Mild Symptoms", "🙂", 0xFFFFB300),
    MODERATE("Moderate Symptoms", "😐", 0xFFFF9800),
    SEVERE("Severe Trouble", "😟", 0xFFE53935)
}

enum class MedicationType(val label: String, val defaultColorHex: Long) {
    RELIEVER("Reliever (Rescue Inhaler)", 0xFF0288D1),
    CONTROLLER("Controller (Preventer)", 0xFFFF9800),
    APPOINTMENT("Doctor / Clinic Visit", 0xFF8E24AA)
}

data class ChildProfile(
    val id: String = "child_1",
    val nickname: String = "Arjun",
    val age: Int = 8,
    val sex: String = "Boy",
    val points: Int = 320,
    val levelName: String = "Level 3 - Breathing Hero",
    val streakDays: Int = 5,
    val emergencyDoctorName: String = "Dr. Anita Sharma (Pediatrician)",
    val emergencyDoctorPhone: String = "911", // Configurable
    val greenZoneAction: String = "Feeling good, no cough or wheeze: Take controller medicine (1 puff daily at bedtime). Continue normal active play!",
    val yellowZoneAction: String = "Coughing or mild wheezing: Take reliever inhaler (2 puffs via spacer). Rest and wait 15 minutes. Notify a parent.",
    val redZoneAction: String = "Severe difficulty breathing, medicine not helping: Take 4-6 puffs of reliever inhaler immediately. Call emergency services or go to nearest clinic right away!"
)

data class ReviewQuestion(
    val id: Int,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)

data class Lesson(
    val id: Int,
    val number: Int,
    val title: String,
    val subtitle: String,
    val durationMinutes: Int,
    val summary: String,
    val fullText: String,
    val quickFact: String,
    val practicalTip: String,
    val questions: List<ReviewQuestion>,
    val isCompleted: Boolean = false,
    val imageResName: String = "img_lungs_comparison"
)

data class Quiz(
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val questions: List<ReviewQuestion>,
    val completed: Boolean = false,
    val score: Int = 0,
    val stars: Int = 0
)

data class SymptomLog(
    val id: String = System.currentTimeMillis().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val dateString: String = "Today",
    val severity: SymptomSeverity = SymptomSeverity.GOOD,
    val symptoms: List<String> = emptyList(),
    val triggers: List<String> = emptyList(),
    val notes: String = ""
)

data class MedicationReminder(
    val id: String,
    val title: String,
    val type: MedicationType,
    val dosageNotes: String,
    val timeString: String,
    val isEnabled: Boolean = true,
    val isTakenToday: Boolean = false
)

data class Badge(
    val id: String,
    val title: String,
    val description: String,
    val iconEmoji: String,
    val isUnlocked: Boolean = false,
    val unlockedDate: String = ""
)

data class ResearchQuestion(
    val id: Int,
    val questionText: String,
    val options: List<String>,
    val correctIndex: Int,
    val domain: String // e.g. "Trigger Recognition", "Inhaler Technique", "Emergency Action"
)

data class ResearchAssessment(
    val participantCode: String = "AP-2026-042",
    val isPreTestCompleted: Boolean = false,
    val preTestScore: Int = 0,
    val preTestTotal: Int = 10,
    val preTestDate: String = "",
    val isPostTestCompleted: Boolean = false,
    val postTestScore: Int = 0,
    val postTestTotal: Int = 10,
    val postTestDate: String = "",
    val isConsentSigned: Boolean = true
)

data class ChatMessage(
    val id: String = System.currentTimeMillis().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isEmergencyAlert: Boolean = false
)

enum class MessageSender {
    USER,
    ASSISTANT
}
