package com.example.ui.screens.games

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Quiz
import com.example.ui.theme.*

@Composable
fun GamesHubScreen(
    quizzes: List<Quiz>,
    onSelectQuiz: (String) -> Unit,
    onPlayTriggerGame: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FBFE))
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "AsthmaPlay Games & Quizzes",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )
                Text(
                    text = "Play exciting mini-games, earn stars, and collect superhero badges!",
                    fontSize = 13.sp,
                    color = Color(0xFF64748B)
                )
            }
        }

        // Featured Mini Game: Trigger Detective
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = WarmOrangeLight),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onPlayTriggerGame)
                    .testTag("trigger_game_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(WarmOrange),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🔍", fontSize = 32.sp)
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "MINI GAME",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = WarmOrange
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "🔥 Popular", fontSize = 11.sp, color = Color(0xFFC2410C))
                        }

                        Text(
                            text = "Trigger Detective",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF7C2D12)
                        )

                        Text(
                            text = "Spot the sneaky airway triggers vs safe healthy items!",
                            fontSize = 12.sp,
                            color = Color(0xFF9A3412),
                            lineHeight = 16.sp
                        )
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Play",
                        tint = WarmOrange
                    )
                }
            }
        }

        // Section Title: Quizzes
        item {
            Text(
                text = "Knowledge Quizzes",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1E293B)
            )
        }

        items(quizzes) { quiz ->
            QuizCard(
                quiz = quiz,
                onClick = { onSelectQuiz(quiz.id) }
            )
        }
    }
}

@Composable
private fun QuizCard(
    quiz: Quiz,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("quiz_card_${quiz.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .background(if (quiz.completed) SoftGreenLight else SkyBlueLight),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (quiz.completed) "🏆" else "❓",
                    fontSize = 24.sp
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = quiz.category,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = SkyBlueDark
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    if (quiz.completed) {
                        Text(
                            text = "Score: ${quiz.score}/${quiz.questions.size}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SoftGreen
                        )
                    }
                }

                Text(
                    text = quiz.title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )

                Text(
                    text = quiz.description,
                    fontSize = 12.sp,
                    color = Color.Gray,
                    maxLines = 2,
                    lineHeight = 16.sp
                )

                if (quiz.completed) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row {
                        repeat(3) { starIdx ->
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = if (starIdx < quiz.stars) GoldenYellow else Color(0xFFE2E8F0),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            Button(
                onClick = onClick,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (quiz.completed) SoftGreen else SkyBlueDark
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(if (quiz.completed) "Replay" else "Play", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
