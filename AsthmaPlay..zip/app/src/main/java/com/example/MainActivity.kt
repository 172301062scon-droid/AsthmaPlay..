package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*

import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.models.UserRole
import com.example.data.repository.AsthmaRepository
import com.example.ui.screens.assistant.AiAssistantScreen
import com.example.ui.screens.games.GamesHubScreen
import com.example.ui.screens.games.QuizPlayScreen
import com.example.ui.screens.games.TriggerGameScreen
import com.example.ui.screens.home.HomeDashboardScreen
import com.example.ui.screens.inhaler.InhalerEducationScreen
import com.example.ui.screens.learn.LearnHubScreen
import com.example.ui.screens.learn.LessonDetailScreen
import com.example.ui.screens.parent.ParentDashboardScreen
import com.example.ui.screens.progress.ProgressScreen
import com.example.ui.screens.reminders.RemindersScreen
import com.example.ui.screens.research.ResearchAssessmentScreen
import com.example.ui.screens.symptoms.SymptomTrackerScreen
import com.example.ui.screens.welcome.LoginRegisterScreen
import com.example.ui.screens.welcome.WelcomeScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SkyBlueDark

sealed class AppScreen {
    object Welcome : AppScreen()
    object LoginRegister : AppScreen()
    object Home : AppScreen()
    object LearnHub : AppScreen()
    data class LessonDetail(val lessonId: Int) : AppScreen()
    object GamesHub : AppScreen()
    data class QuizPlay(val quizId: String) : AppScreen()
    object TriggerGame : AppScreen()
    object AiAssistant : AppScreen()
    object InhalerGuide : AppScreen()
    object SymptomTracker : AppScreen()
    object Reminders : AppScreen()
    object Progress : AppScreen()
    object ParentDashboard : AppScreen()
    object ResearchAssessment : AppScreen()
}

class MainActivity : ComponentActivity() {

    private lateinit var repository: AsthmaRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        repository = AsthmaRepository(applicationContext)

        setContent {
            MyApplicationTheme {
                AsthmaPlayApp(repository = repository)
            }
        }
    }
}

@Composable
fun AsthmaPlayApp(repository: AsthmaRepository) {
    var currentScreen by remember { mutableStateOf<AppScreen>(AppScreen.Home) }

    val currentRole by repository.currentRole.collectAsStateWithLifecycle()
    val childProfile by repository.childProfile.collectAsStateWithLifecycle()
    val lessons by repository.lessons.collectAsStateWithLifecycle()
    val quizzes by repository.quizzes.collectAsStateWithLifecycle()
    val reminders by repository.reminders.collectAsStateWithLifecycle()
    val symptomLogs by repository.symptomLogs.collectAsStateWithLifecycle()
    val badges by repository.badges.collectAsStateWithLifecycle()
    val researchAssessment by repository.researchAssessment.collectAsStateWithLifecycle()

    // Determine bottom nav visibility
    val isBottomNavVisible = when (currentScreen) {
        AppScreen.Home, AppScreen.LearnHub, AppScreen.GamesHub, AppScreen.Progress -> true
        else -> false
    }

    // Top-level back handler
    BackHandler(enabled = currentScreen != AppScreen.Home && currentScreen != AppScreen.Welcome) {
        when (currentScreen) {
            is AppScreen.LessonDetail -> currentScreen = AppScreen.LearnHub
            is AppScreen.QuizPlay, AppScreen.TriggerGame -> currentScreen = AppScreen.GamesHub
            AppScreen.ResearchAssessment -> currentScreen = AppScreen.ParentDashboard
            else -> currentScreen = AppScreen.Home
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (isBottomNavVisible) {
                NavigationBar(
                    containerColor = Color.White,
                    tonalElevation = 6.dp,
                    windowInsets = WindowInsets.navigationBars,
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.Home,
                        onClick = { currentScreen = AppScreen.Home },
                        icon = {
                            Icon(
                                if (currentScreen == AppScreen.Home) Icons.Filled.Home else Icons.Outlined.Home,
                                contentDescription = "Home"
                            )
                        },
                        label = { Text("Home", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SkyBlueDark,
                            selectedTextColor = SkyBlueDark,
                            indicatorColor = Color(0xFFE1F5FE)
                        ),
                        modifier = Modifier.testTag("nav_item_home")
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppScreen.LearnHub || currentScreen is AppScreen.LessonDetail,
                        onClick = { currentScreen = AppScreen.LearnHub },
                        icon = {
                            Icon(
                                Icons.AutoMirrored.Filled.MenuBook,
                                contentDescription = "Learn"
                            )
                        },
                        label = { Text("Learn", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SkyBlueDark,
                            selectedTextColor = SkyBlueDark,
                            indicatorColor = Color(0xFFE1F5FE)
                        ),
                        modifier = Modifier.testTag("nav_item_learn")
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppScreen.GamesHub || currentScreen is AppScreen.QuizPlay || currentScreen == AppScreen.TriggerGame,
                        onClick = { currentScreen = AppScreen.GamesHub },
                        icon = {
                            Icon(
                                if (currentScreen == AppScreen.GamesHub) Icons.Filled.SportsEsports else Icons.Outlined.SportsEsports,
                                contentDescription = "Games"
                            )
                        },
                        label = { Text("Games", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SkyBlueDark,
                            selectedTextColor = SkyBlueDark,
                            indicatorColor = Color(0xFFE1F5FE)
                        ),
                        modifier = Modifier.testTag("nav_item_games")
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppScreen.Progress,
                        onClick = { currentScreen = AppScreen.Progress },
                        icon = {
                            Icon(
                                if (currentScreen == AppScreen.Progress) Icons.Filled.Person else Icons.Outlined.Person,
                                contentDescription = "Profile"
                            )
                        },
                        label = { Text("Profile", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SkyBlueDark,
                            selectedTextColor = SkyBlueDark,
                            indicatorColor = Color(0xFFE1F5FE)
                        ),
                        modifier = Modifier.testTag("nav_item_profile")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val screen = currentScreen) {
                AppScreen.Welcome -> {
                    WelcomeScreen(
                        onGetStarted = { currentScreen = AppScreen.Home },
                        onLoginClick = { currentScreen = AppScreen.LoginRegister }
                    )
                }

                AppScreen.LoginRegister -> {
                    LoginRegisterScreen(
                        currentNickname = childProfile.nickname,
                        currentAge = childProfile.age,
                        currentSex = childProfile.sex,
                        onSuccessLogin = { role, nickname, age, sex ->
                            repository.switchRole(role)
                            repository.updateChildProfile(nickname, age, sex, childProfile.emergencyDoctorName, childProfile.emergencyDoctorPhone)
                            when (role) {
                                UserRole.CHILD -> currentScreen = AppScreen.Home
                                UserRole.PARENT -> currentScreen = AppScreen.ParentDashboard
                                UserRole.RESEARCHER -> currentScreen = AppScreen.ResearchAssessment
                            }
                        },
                        onBack = { currentScreen = AppScreen.Home }
                    )
                }

                AppScreen.Home -> {
                    val firstUnfinishedLesson = lessons.firstOrNull { !it.isCompleted } ?: lessons.firstOrNull()
                    HomeDashboardScreen(
                        childProfile = childProfile,
                        todayLesson = firstUnfinishedLesson,
                        reminders = reminders,
                        onNavigateToLearn = { currentScreen = AppScreen.LearnHub },
                        onNavigateToLesson = { lessonId -> currentScreen = AppScreen.LessonDetail(lessonId) },
                        onNavigateToGames = { currentScreen = AppScreen.GamesHub },
                        onNavigateToAssistant = { currentScreen = AppScreen.AiAssistant },
                        onNavigateToProgress = { currentScreen = AppScreen.Progress },
                        onNavigateToReminders = { currentScreen = AppScreen.Reminders },
                        onNavigateToInhalerGuide = { currentScreen = AppScreen.InhalerGuide },
                        onNavigateToSymptoms = { currentScreen = AppScreen.SymptomTracker },
                        onOpenParentDashboard = { currentScreen = AppScreen.ParentDashboard },
                        onToggleReminderTaken = { remId -> repository.markReminderTaken(remId) }
                    )
                }

                AppScreen.LearnHub -> {
                    LearnHubScreen(
                        lessons = lessons,
                        onSelectLesson = { lessonId -> currentScreen = AppScreen.LessonDetail(lessonId) }
                    )
                }

                is AppScreen.LessonDetail -> {
                    val targetLesson = lessons.find { it.id == screen.lessonId } ?: lessons.first()
                    LessonDetailScreen(
                        lesson = targetLesson,
                        totalLessons = lessons.size,
                        onBack = { currentScreen = AppScreen.LearnHub },
                        onCompleteLesson = { id -> repository.markLessonCompleted(id) },
                        onNextLesson = if (screen.lessonId < lessons.size) {
                            { nextId -> currentScreen = AppScreen.LessonDetail(nextId) }
                        } else null
                    )
                }

                AppScreen.GamesHub -> {
                    GamesHubScreen(
                        quizzes = quizzes,
                        onSelectQuiz = { quizId -> currentScreen = AppScreen.QuizPlay(quizId) },
                        onPlayTriggerGame = { currentScreen = AppScreen.TriggerGame }
                    )
                }

                is AppScreen.QuizPlay -> {
                    val targetQuiz = quizzes.find { it.id == screen.quizId } ?: quizzes.first()
                    QuizPlayScreen(
                        quiz = targetQuiz,
                        onBack = { currentScreen = AppScreen.GamesHub },
                        onQuizCompleted = { qId, score, total ->
                            repository.recordQuizCompletion(qId, score, total)
                        }
                    )
                }

                AppScreen.TriggerGame -> {
                    TriggerGameScreen(
                        onBack = { currentScreen = AppScreen.GamesHub },
                        onAwardPoints = { pts -> repository.addPoints(pts) }
                    )
                }

                AppScreen.AiAssistant -> {
                    AiAssistantScreen(
                        onBack = { currentScreen = AppScreen.Home }
                    )
                }

                AppScreen.InhalerGuide -> {
                    InhalerEducationScreen(
                        onBack = { currentScreen = AppScreen.Home },
                        onMastered = {
                            repository.addPoints(20)
                            currentScreen = AppScreen.Home
                        }
                    )
                }

                AppScreen.SymptomTracker -> {
                    SymptomTrackerScreen(
                        symptomLogs = symptomLogs,
                        onSaveLog = { severity, syms, trigs, notes ->
                            repository.addSymptomLog(severity, syms, trigs, notes)
                        },
                        onBack = { currentScreen = AppScreen.Home }
                    )
                }

                AppScreen.Reminders -> {
                    RemindersScreen(
                        reminders = reminders,
                        onToggleReminder = { id -> repository.toggleReminder(id) },
                        onMarkTaken = { id -> repository.markReminderTaken(id) },
                        onAddReminder = { title, type, time, notes ->
                            repository.addReminder(title, type, time, notes)
                        },
                        onBack = { currentScreen = AppScreen.Home }
                    )
                }

                AppScreen.Progress -> {
                    ProgressScreen(
                        childProfile = childProfile,
                        lessons = lessons,
                        quizzes = quizzes,
                        badges = badges,
                        onAwardBreathingPoints = { repository.addPoints(10) }
                    )
                }

                AppScreen.ParentDashboard -> {
                    ParentDashboardScreen(
                        childProfile = childProfile,
                        lessons = lessons,
                        reminders = reminders,
                        symptomLogs = symptomLogs,
                        onVerifyPin = { pin -> repository.verifyParentPin(pin) },
                        onUpdatePin = { newPin -> repository.updateParentPin(newPin) },
                        onUpdateProfile = { name, age, sex, doc, phone ->
                            repository.updateChildProfile(name, age, sex, doc, phone)
                        },
                        onBackToChildMode = { currentScreen = AppScreen.Home },
                        onNavigateToResearch = { currentScreen = AppScreen.ResearchAssessment }
                    )
                }

                AppScreen.ResearchAssessment -> {
                    ResearchAssessmentScreen(
                        assessment = researchAssessment,
                        questions = repository.getResearchQuestions(),
                        lessons = lessons,
                        onSubmitPreTest = { score, total ->
                            repository.submitResearchPreTest(score, total)
                        },
                        onSubmitPostTest = { score, total ->
                            repository.submitResearchPostTest(score, total)
                        },
                        onBack = { currentScreen = AppScreen.ParentDashboard }
                    )
                }
            }
        }
    }
}
