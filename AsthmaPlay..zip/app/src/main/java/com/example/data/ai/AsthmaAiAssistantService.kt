package com.example.data.ai

import android.content.Context
import com.example.BuildConfig
import com.example.data.models.ChatMessage
import com.example.data.models.MessageSender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AsthmaAiAssistantService(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    // Safety Emergency keywords
    private val emergencyKeywords = listOf(
        "can't breathe", "cannot breathe", "hard to breathe", "trouble breathing",
        "choking", "blue lips", "gasping", "emergency", "chest pain", "dying", "passed out"
    )

    fun isEmergencyQuestion(query: String): Boolean {
        val lower = query.lowercase()
        return emergencyKeywords.any { lower.contains(it) }
    }

    suspend fun askAssistant(userQuery: String): ChatMessage = withContext(Dispatchers.IO) {
        val trimmed = userQuery.trim()

        // 1. Critical safety rule check: Emergency detection
        if (isEmergencyQuestion(trimmed)) {
            return@withContext ChatMessage(
                sender = MessageSender.ASSISTANT,
                text = "🚨 IMPORTANT SAFETY ALERT:\n\n" +
                        "If you are having severe difficulty breathing right now, STOP and tell a grown-up or parent IMMEDIATELY!\n\n" +
                        "1. Take 2 to 4 puffs of your blue reliever inhaler using your spacer.\n" +
                        "2. Sit up straight (do not lie down).\n" +
                        "3. Have an adult call emergency services (911 / 112 / 108) or your doctor right now.\n\n" +
                        "Do not keep chatting—please go get an adult to help you right this second!",
                isEmergencyAlert = true
            )
        }

        // 2. Check for medication alteration questions
        val lower = trimmed.lowercase()
        if (lower.contains("stop medicine") || lower.contains("change dose") || lower.contains("skip inhaler")) {
            return@withContext ChatMessage(
                sender = MessageSender.ASSISTANT,
                text = "Remember superhero rule: Never change how much medicine you take or stop your inhaler on your own! Only your doctor or parent can decide your medicine plan. Always ask your parent or doctor before changing anything."
            )
        }

        // 3. Try Gemini API if BuildConfig.GEMINI_API_KEY is available
        val apiKey = try {
            BuildConfig::class.java.getField("GEMINI_API_KEY").get(null) as? String ?: ""
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isNotBlank() && !apiKey.equals("MY_GEMINI_API_KEY", ignoreCase = true) && !apiKey.equals("PLACEHOLDER_KEY", ignoreCase = true)) {

            try {
                val apiResponse = callGeminiApi(trimmed, apiKey)
                if (!apiResponse.isNullOrBlank()) {
                    return@withContext ChatMessage(
                        sender = MessageSender.ASSISTANT,
                        text = apiResponse
                    )
                }
            } catch (e: Exception) {
                // Fallback to grounded pediatric clinical knowledge base
            }
        }

        // 4. Grounded Pediatric Knowledge Base Fallback
        val response = getClinicianGroundedResponse(trimmed)
        ChatMessage(
            sender = MessageSender.ASSISTANT,
            text = response
        )
    }

    private fun callGeminiApi(userQuery: String, apiKey: String): String? {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey"
        val systemPrompt = "You are AsthmaBuddy, a warm, reassuring, certified pediatric asthma educational robot mascot for school-age children (aged 6 to 12). " +
                "RULES: 1. Keep answers short (2 to 4 friendly sentences), simple English, encouraging and easy for a 7-year-old child to understand. " +
                "2. NEVER diagnose, prescribe medications, or advise changing doses. " +
                "3. Emphasize that controllers protect lungs daily and blue relievers soothe tight airways. " +
                "4. Always encourage telling a parent, teacher, or nurse if they feel unwell. " +
                "5. Never use scary medical terms; use analogies like friendly tree branches, balloons, slides."

        val jsonPayload = JSONObject().apply {
            val contents = JSONArray().apply {
                val contentObj = JSONObject().apply {
                    val parts = JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", "System instruction: $systemPrompt\n\nChild's question: $userQuery")
                        })
                    }
                    put("parts", parts)
                }
                put(contentObj)
            }
            put("contents", contents)
        }

        val body = jsonPayload.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder().url(url).post(body).build()

        client.newCall(request).execute().use { response ->
            if (response.isSuccessful) {
                val responseBody = response.body?.string() ?: return null
                val root = JSONObject(responseBody)
                val candidates = root.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val content = firstCandidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        return parts.getJSONObject(0).optString("text")
                    }
                }
            }
        }
        return null
    }

    private fun getClinicianGroundedResponse(query: String): String {
        val q = query.lowercase()
        return when {
            q.contains("why do i have asthma") || q.contains("cause") ->
                "Asthma is just the way your lungs are built—their breathing tubes are a little extra sensitive to the world around them! It isn't anything you did wrong, and you can't give it to anyone. Lots of awesome kids, athletes, and rockstars have asthma too!"

            q.contains("cough") || q.contains("why do i cough") ->
                "When your airways tickle or get a little swollen, your lungs cough to try to clear a path for fresh air! It's like a soft alarm bell telling you and your parents that your airways might need a little help from your blue reliever inhaler."

            q.contains("trigger") || q.contains("what can trigger") ->
                "Triggers are sneaky things that bother your sensitive airways! Common ones are pollen from flowers, cold winter air, dust mites in pillows, cigarette smoke, and pet fur. Once you know your triggers, you can stay away from them like a superhero dodging lasers!"

            q.contains("how do i use my inhaler") || q.contains("spacer") || q.contains("inhaler") ->
                "Here are the super steps: 1. Shake the inhaler! 2. Click it into your spacer. 3. Breathe out gently. 4. Seal your lips around the spacer. 5. Press down ONCE. 6. Breathe in and out slowly 5 times! Check out the Inhaler tab in AsthmaPlay to see pictures of each step!"

            q.contains("sport") || q.contains("play") || q.contains("exercise") || q.contains("run") || q.contains("soccer") ->
                "Yes, absolutely! Exercise makes your lungs stronger and healthier! Just remember to do a gentle 5-minute warm-up first, and carry your blue reliever inhaler in your sports bag. If your chest feels tight during the game, take a breather on the bench."

            q.contains("short of breath") || q.contains("tight") || q.contains("wheez") ->
                "If your chest feels tight or you hear a whistle when you breathe, sit down calmly and take your blue reliever inhaler with your spacer. Tell your parent or teacher right away so they can keep an eye on you and follow your Asthma Action Plan!"

            q.contains("controller") || q.contains("preventer") || q.contains("daily") ->
                "Your controller medicine is your daily superhero shield! Even when you feel 100% fantastic, taking it morning and night keeps swelling asleep inside your airways so surprise flare-ups stay far away!"

            q.contains("reliever") || q.contains("blue") ->
                "Your blue reliever inhaler is your fast rescue friend! It opens up tight breathing muscles in just a few minutes whenever you feel coughing or wheezing."

            q.contains("asthma go away") || q.contains("cure") ->
                "While asthma stays with you for a while, many children find their airways get much stronger and easier to manage as they grow older! By taking your daily controller medicine, your lungs can stay happy and super strong."

            else ->
                "That's a fantastic question about your lungs! Your airways work hard every day to bring fresh oxygen into your body. Remember to take your daily controller inhaler and always tell a parent or doctor if your chest ever feels tight. Would you like to learn about triggers, sports, or how to use a spacer?"
        }
    }
}
